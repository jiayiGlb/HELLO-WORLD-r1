const MyElement = ()=>{
    return <div><h1> Hello World </h1><h1>{new Date().toLocaleTimeString()}</h1></div>
}

export default MyElement